import json

credentials = {
    "EScreen URL": "https://www.myescreen.com/V3/DefaultRoute.htm",
    "Esusername": "YBOT19",
    "Espassword": "Bluebird1@5",
    "Fuse URL": "https://fuse.i-t-g.net/login.php",
    "Fusername": "ybot",
    "Fpassword": "Bluebird1@3",
    "Default_Path": "C:\\Users\\Administrator\\OneDrive - ITG Communications, LLC\\onboarding_data\\Onboarding_Comcast\\Technician_Details",
    "Logfile" : "C:\\Users\\Administrator\\OneDrive - ITG Communications, LLC\\onboarding_data\\Onboarding_Comcast\\Log\\DT_BGV_initiation",
    "OffPhNo" : "7312361130",
    "Distance" : "50",
    "ybotID" : "ybot@i-t-g.net",
    "Botmailid" : "ybot@i-t-g.net",
    "Recipient" :  "ybot@i-t-g.net",
    "Businessdays" : "3",
    "LOOP_INTERVAL" : "5s",
    "MAX_ITERATIONS" : "2",
    "DB_HOST" : "onboarding-app-db.cluster-cesmhx7exvaw.us-east-2.rds.amazonaws.com",
    "DB_PORT" : "5432",
    "DB_NAME" : "onboardingdb",
    "DB_USERNAME" : "postgres",
    "DB_PASSWORD" : "+U%xLgV:ze-4PZUS7Mp~(}2~Hn{6",
}

with open("credentials1.json", "w") as json_file:
    json.dump(credentials, json_file)